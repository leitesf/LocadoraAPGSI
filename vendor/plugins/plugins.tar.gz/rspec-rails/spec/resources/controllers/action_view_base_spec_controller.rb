class ActionViewBaseSpecController < ActionController::Base
end
