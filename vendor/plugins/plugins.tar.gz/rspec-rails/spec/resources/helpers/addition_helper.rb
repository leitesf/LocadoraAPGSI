module AdditionHelper
  def plus(addend)
    @addend + addend
  end
end
