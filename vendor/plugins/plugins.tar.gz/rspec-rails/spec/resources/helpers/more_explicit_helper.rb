module MoreExplicitHelper
  def method_in_more_explicit_helper
    "<div>This is text from a method in the MoreExplicitHelper</div>"
  end
end
