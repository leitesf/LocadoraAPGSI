# Methods added to this helper will be available to all templates in the application.
module ApplicationHelper
  def method_in_plugin_application_helper
    "<div>This is text from a method in the ApplicationHelper</div>"
  end
end
