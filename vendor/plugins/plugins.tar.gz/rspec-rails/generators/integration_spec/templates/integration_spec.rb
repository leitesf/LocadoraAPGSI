require 'spec_helper'

describe "<%= class_name.pluralize %>" do
end
