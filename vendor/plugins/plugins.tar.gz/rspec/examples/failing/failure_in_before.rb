describe "This example" do
  
  before(:each) do
    NonExistentClass.new
  end
  
  it "should be listed as failing in each" do
  end
  
end
