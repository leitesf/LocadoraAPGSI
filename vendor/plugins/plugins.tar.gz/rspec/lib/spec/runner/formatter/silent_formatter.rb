require 'spec/runner/formatter/base_formatter'

module Spec
  module Runner
    module Formatter
      class SilentFormatter < BaseFormatter
      end
    end
  end
end
