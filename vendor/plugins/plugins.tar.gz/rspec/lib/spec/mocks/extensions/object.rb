class Object
  include Spec::Mocks::Methods
end
