require 'spec_helper'

describe "c" do

  it "1" do
  end

  it "2" do
  end

end

describe "d" do

  it "3" do
  end

  it "4" do
  end

end

class LineNumberQuerySubject
end

describe LineNumberQuerySubject do

  it "5" do
  end

end

describe LineNumberQuerySubject, "described" do

  it "6" do
  end

end

describe LineNumberQuerySubject, "described", :something => :something_else do

   it "7" do
   end

end

describe "described", :something => :something_else do

  it "8" do
  end

end

describe "e" do

  it "9" do
  end

  it "10" do
  end

  describe "f" do
    it "11" do
    end

    it "12" do
    end
  end

end
