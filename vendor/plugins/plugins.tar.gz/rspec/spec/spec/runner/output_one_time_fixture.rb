require 'spec_helper'

describe "Running an Example" do
  it "should not output twice" do
    true.should be_true
  end
end