context 'foo' do
  subject { [] }
  its(:size) { should == 1 }
end
